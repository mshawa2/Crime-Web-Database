//
// One Crime
//

namespace crimes.Models
{

  public class Areas
	{
	
		// data members with auto-generated getters and setters:
	  public int NumArea { get; set; }
		public string AreaNum { get; set; }
		public int AreaCrimeNum { get; set; }
        public double Percrime{get; set; }
	
		// default constructor:
		public Areas()
		{ }
		
		// constructor:
		public Areas(int id, string desc1, int avg, double avg2)
		{
			NumArea = id;
			AreaNum = desc1;
			AreaCrimeNum = avg;
            Percrime = avg2;
		}
		
	}//class

}//namespace
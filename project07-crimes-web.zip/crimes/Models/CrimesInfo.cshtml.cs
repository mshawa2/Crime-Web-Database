using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class CrimesInfoModel : PageModel  
    {  
				public List<Models.Crime> CrimesList { get; set; }
				public string Input { get; set; }
                public string areaName{get; set; }
				public int NumCrimes { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  List<Models.Crime> crimes = new List<Models.Crime>();
					
					// make input available to web page:
					Input = input;
					
					// clear exception:
					EX = null;
					
					try
					{
						//
						// Do we have an input argument?  If so, we do a lookup:
						//
						if (input == null)
						{
							//
							// there's no page argument, perhaps user surfed to the page directly?  
							// In this case, nothing to do.
							//
						}
						else  
						{
							// 
							// Lookup movie(s) based on input, which could be id or a partial name:
							// 
							int id;
							string sql;

							if (System.Int32.TryParse(input, out id))
							{
								// lookup movie by movie id:
								sql = string.Format(@"
DECLARE @total AS FLOAT;
SET @total = (SELECT COUNT(*) FROM Crimes WHERE Area = {0});

SELECT TOP 10 Crimes.IUCR, COUNT(*) AS NumCrimes, PrimaryDesc, SecondaryDesc, ROUND((COUNT(*)/@total *100), 2) AS PerCrimes, ROUND((SUM(CONVERT(float, Crimes.Arrested))/Count(*) *100), 2) AS PerArrested, Areas.AreaName
FROM Crimes
INNER JOIN Codes on Crimes.IUCR = Codes.IUCR
INNER JOIN Areas on Crimes.Area = Areas.Area 
WHERE Areas.Area = {0}
GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc, Areas.AreaName
ORDER BY COUNT(*) DESC;
", id);
							}
							else
							{
								// lookup movie(s) by partial name match:
								input = input.Replace("'", "''");

								sql = string.Format(@"
DECLARE @total AS FLOAT;
SET @total = (SELECT COUNT(*) FROM Crimes INNER JOIN Areas on Crimes.Area = Areas.Area WHERE Areas.AreaName = '{0}');

SELECT TOP 10 Crimes.IUCR, COUNT(*) AS NumCrimes,@total AS tots, PrimaryDesc, SecondaryDesc, ROUND((COUNT(*)/@total *100), 2) AS PerCrimes, ROUND((SUM(CONVERT(float, Crimes.Arrested))/Count(*) *100), 2) AS PerArrested, Areas.AreaName
FROM Crimes
INNER JOIN Codes on Crimes.IUCR = Codes.IUCR
INNER JOIN Areas on Crimes.Area = Areas.Area 
WHERE Areas.AreaName = '{0}'
GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc, Areas.AreaName
ORDER BY COUNT(*) DESC", input);
							}

							DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

							foreach (DataRow row in ds.Tables[0].Rows)
						{
							Models.Crime m = new Models.Crime();

							m.IUCR = Convert.ToString(row["IUCR"]);
							m.NumCrimes = Convert.ToInt32(row["NumCrimes"]);
							m.PrimaryDesc = Convert.ToString(row["PrimaryDesc"]);
							m.SecondaryDesc = Convert.ToString(row["SecondaryDesc"]);
							m.PerCrimes = Convert.ToDouble(row["PerCrimes"]);
                            m.PerArrest = Convert.ToDouble(row["PerArrested"]);
                            areaName = Convert.ToString(row["AreaName"]);

							crimes.Add(m);
						}//else
					}
                    }
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  CrimesList = crimes;
					  NumCrimes = crimes.Count;
				  }
				}
			
    }//class  
}//namespace
using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class AllAreaInfoModel : PageModel  
    {  
				public List<Models.Areas> CrimesList { get; set; }
				public string Input { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  List<Models.Areas> crimes = new List<Models.Areas>();
					
					
					// clear exception:
					EX = null;
					
					try
					{
							// 
							// Lookup movie(s) based on input, which could be id or a partial name:
							// 
							// 
							string sql;
								// lookup movie by movie id:
								sql = string.Format(@"
DECLARE @total AS FLOAT;
SET @total = (SELECT COUNT(*) FROM Crimes);

SELECT Areas.Area, Areas.AreaName, COUNT(*) AS AreaCrimeNum, ROUND((COUNT(*)/@total *100), 2) AS Percrime
FROM Crimes
INNER JOIN Areas on Crimes.Area = Areas.Area
WHERE Areas.Area != 0
GROUP BY Areas.Area, Areas.AreaName
ORDER BY Areas.AreaName DESC
");

							DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

							foreach (DataRow row in ds.Tables[0].Rows)
						{
							Models.Areas m = new Models.Areas();

							m.NumArea = Convert.ToInt32(row["Area"]);
							m.AreaNum = Convert.ToString(row["AreaName"]);
							m.AreaCrimeNum = Convert.ToInt32(row["AreaCrimeNum"]);
							m.Percrime = Convert.ToDouble(row["Percrime"]);

							crimes.Add(m);
						}//else
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  CrimesList = crimes;
				  }
				}
			
    }//class  
}//namespace
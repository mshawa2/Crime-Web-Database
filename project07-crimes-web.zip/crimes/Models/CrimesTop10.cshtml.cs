using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class CrimesTop10Model : PageModel  
    {  
        public List<Models.Crime> CrimesList { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet()  
        {  
				  List<Models.Crime> Crimes = new List<Models.Crime>();
					
					// clear exception:
					EX = null;
					
					try
					{
						string sql = string.Format(@"
DECLARE @total AS FLOAT;
SET @total = (SELECT COUNT(*) FROM Crimes);

SELECT TOP 10 Crimes.IUCR, COUNT(*) AS NumCrimes, PrimaryDesc, SecondaryDesc, ROUND((COUNT(*)/@total *100), 2) AS PerCrimes, ROUND((SUM(CONVERT(float, Crimes.Arrested))/Count(*) *100), 2) AS PerArrested
FROM Crimes
INNER JOIN Codes on Crimes.IUCR = Codes.IUCR
GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc
ORDER BY COUNT(*) DESC;
");

						DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

						foreach (DataRow row in ds.Tables[0].Rows)
						{
							Models.Crime m = new Models.Crime();

							m.IUCR = Convert.ToString(row["IUCR"]);
							m.NumCrimes = Convert.ToInt32(row["NumCrimes"]);
							m.PrimaryDesc = Convert.ToString(row["PrimaryDesc"]);
							m.SecondaryDesc = Convert.ToString(row["SecondaryDesc"]);
							m.PerCrimes = Convert.ToDouble(row["PerCrimes"]);
                            m.PerArrest = Convert.ToDouble(row["PerArrested"]);

							Crimes.Add(m);
						}
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
            CrimesList = Crimes;  
				  }
        }  
				
    }//class
}//namespace
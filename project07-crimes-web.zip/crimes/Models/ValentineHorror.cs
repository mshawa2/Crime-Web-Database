using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class ValentineHorrorModel : PageModel  
    {  
        public List<Models.Areas> CrimesList { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet()  
        {  
				  List<Models.Areas> Crimes = new List<Models.Areas>();
					
					// clear exception:
					EX = null;
					
					try
					{
						string sql = string.Format(@"
SELECT Areas.Area, Areas.AreaName, COUNT(*) AS AreaCrimeNum
FROM Crimes
INNER JOIN Areas on Crimes.Area = Areas.Area
WHERE Crimes.CrimeDate LIKE '%2-14%' AND Crimes.Area != 0
GROUP BY Areas.Area, Areas.AreaName
ORDER BY COUNT(*) DESC
");

						DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

						foreach (DataRow row in ds.Tables[0].Rows)
						{
							Models.Areas m = new Models.Areas();

							m.NumArea = Convert.ToInt32(row["Area"]);
							m.AreaNum = Convert.ToString(row["AreaName"]);
							m.AreaCrimeNum = Convert.ToInt32(row["AreaCrimeNum"]);

							Crimes.Add(m);
						}
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
            CrimesList = Crimes;  
				  }
        }  
				
    }//class
}//namespace
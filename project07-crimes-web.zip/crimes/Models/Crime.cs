//
// One Crime
//

namespace crimes.Models
{

  public class Crime
	{
	
		// data members with auto-generated getters and setters:
	  public string IUCR { get; set; }
		public int NumCrimes { get; set; }
		public string PrimaryDesc { get; set; }
		public string SecondaryDesc { get; set; }
		public double PerCrimes { get; set; }
        public double PerArrest{get; set; }
	
		// default constructor:
		public Crime()
		{ }
		
		// constructor:
		public Crime(string id, int total, string desc1, string desc2, double avg, double avg2)
		{
			IUCR = id;
			NumCrimes = total;
			PrimaryDesc = desc1;
			SecondaryDesc = desc2;
			PerCrimes = avg;
            PerArrest = avg2;
		}
		
	}//class

}//namespace
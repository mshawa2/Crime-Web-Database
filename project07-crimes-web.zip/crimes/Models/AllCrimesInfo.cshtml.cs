using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Threading.Tasks;  
using Microsoft.AspNetCore.Mvc;  
using Microsoft.AspNetCore.Mvc.RazorPages;  
using System.Data;
  
namespace crimes.Pages  
{  
    public class AllCrimesInfoModel : PageModel  
    {  
				public List<Models.Crime> CrimesList { get; set; }
				public string Input { get; set; }
				public Exception EX { get; set; }
  
        public void OnGet(string input)  
        {  
				  List<Models.Crime> crimes = new List<Models.Crime>();
					
					
					// clear exception:
					EX = null;
					
					try
					{
							// 
							// Lookup movie(s) based on input, which could be id or a partial name:
							// 
							// 
							string sql;
								// lookup movie by movie id:
								sql = string.Format(@"
SELECT Crimes.IUCR, COUNT(*) AS NumCrimes, PrimaryDesc, SecondaryDesc
FROM Crimes
RIGHT JOIN Codes on Crimes.IUCR = Codes.IUCR
GROUP BY Crimes.IUCR, PrimaryDesc, SecondaryDesc
ORDER BY PrimaryDesc, SecondaryDesc DESC;
");

							DataSet ds = DataAccessTier.DB.ExecuteNonScalarQuery(sql);

							foreach (DataRow row in ds.Tables[0].Rows)
						{
							Models.Crime m = new Models.Crime();

							m.IUCR = Convert.ToString(row["IUCR"]);
							m.NumCrimes = Convert.ToInt32(row["NumCrimes"]);
							m.PrimaryDesc = Convert.ToString(row["PrimaryDesc"]);
							m.SecondaryDesc = Convert.ToString(row["SecondaryDesc"]);

							crimes.Add(m);
						}//else
					}
					catch(Exception ex)
					{
					  EX = ex;
					}
					finally
					{
					  CrimesList = crimes;
				  }
				}
			
    }//class  
}//namespace